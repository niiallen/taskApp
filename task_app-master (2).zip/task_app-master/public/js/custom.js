$('.alert').hide(5000);

