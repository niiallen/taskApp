@extends('layouts.parent')
<!--Content to serve-->
@section('killer')

    <p>Welcome to our task app!!</p>


@endsection